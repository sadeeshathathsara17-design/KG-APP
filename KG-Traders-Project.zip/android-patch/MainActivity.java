package com.kgtraders.app;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.getcapacitor.BridgeActivity;

import java.io.File;
import java.io.FileOutputStream;

/**
 * Exposes window.AndroidWA.sendBill(base64Png, phoneNumber, customerName) to the web app.
 * Opens the customer's WhatsApp chat with the bill image already attached (only Send is left).
 */
public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getBridge().getWebView().addJavascriptInterface(new WaBridge(), "AndroidWA");
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override public void run() { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show(); }
        });
    }

    private static String normalize(String number) {
        if (number == null) return "";
        String d = number.replaceAll("[^0-9]", "");
        if (d.startsWith("00")) d = d.substring(2);
        if (d.startsWith("0")) d = "94" + d.substring(1);       // Sri Lanka local format -> international
        else if (d.length() == 9) d = "94" + d;
        return d;
    }

    private void share(Uri uri, String digits) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("image/png");
        i.putExtra(Intent.EXTRA_STREAM, uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if (digits.length() > 0) i.putExtra("jid", digits + "@s.whatsapp.net");
        String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b"};
        for (String p : pkgs) {
            try {
                i.setPackage(p);
                startActivity(i);
                return;
            } catch (ActivityNotFoundException ignored) { }
        }
        i.setPackage(null);
        i.removeExtra("jid");
        startActivity(Intent.createChooser(i, "Share bill"));
    }

    private class WaBridge {
        @JavascriptInterface
        public void sendBill(String base64, String number, String name) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                File dir = new File(getCacheDir(), "bills");
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, "bill.png");
                FileOutputStream fo = new FileOutputStream(f);
                fo.write(data);
                fo.close();
                final Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", f);
                final String digits = normalize(number);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        try { share(uri, digits); }
                        catch (Exception e) { toast("Could not open WhatsApp: " + e.getMessage()); }
                    }
                });
            } catch (Exception e) {
                toast("Could not share bill: " + e.getMessage());
            }
        }
    }
}
