# KG Traders App

1. Upload everything in this folder to a GitHub repository (main branch).
2. Open the repo > Actions tab > "Build KG Traders APK". It starts by itself on every upload (or press "Run workflow").
3. After about 5-8 minutes download KG-Traders.apk from the repo's Releases section (right side of the repo page) or from the finished run (Artifacts).

To change the app: replace `www/index.html` and upload again. A new APK is built.
